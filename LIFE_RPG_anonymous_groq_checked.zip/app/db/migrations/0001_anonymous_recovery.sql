-- Adds a one-way hash for the user's portable recovery code.
ALTER TABLE `users` ADD COLUMN `recoveryCodeHash` varchar(64) NULL;
